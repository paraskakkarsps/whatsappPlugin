 (function() {
	$(document).ready(function() {
			$(".wa__btn_popup").click(function(){
				$(".wa__popup_chat_box").toggleClass("wa__active");
			});
			$(".cross").click(function(){
				$(".wa__popup_chat_box").toggleClass("wa__active");
			});
	});
 })(jQuery);