<?php
/*
*  Plugin Name: WhatsApp Connect
 * Plugin URI: https://softprodigy.com/
 * Description:WhatsApp Connect for WordPress allows your customers to open a conversation from your website directly to your WhatsApp phone number.
 * Version:           1.1.0
 * Author:            SoftProdigy
 * Author URI:        https://softprodigy.com


*/

	# Plugin activation hook
	// Require once the Composer Autoload
	if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
		require_once dirname( __FILE__ ) . '/vendor/autoload.php';
	}

	/**
	 * The code that runs during plugin activation
	 */
	function activate_alecaddd_plugin() {
		Inc\Base\Activate::activate();
	}
	register_activation_hook( __FILE__, 'activate_alecaddd_plugin' );

	/**
	 * The code that runs during plugin deactivation
	 */
	function deactivate_alecaddd_plugin() {
		Inc\Base\Deactivate::deactivate();
	}
	register_deactivation_hook( __FILE__, 'deactivate_alecaddd_plugin' );

	/**
	 * Initialize all the core classes of the plugin
	 */
	if ( class_exists( 'Inc\\Init' ) ) {
		Inc\Init::register_services();
	}
