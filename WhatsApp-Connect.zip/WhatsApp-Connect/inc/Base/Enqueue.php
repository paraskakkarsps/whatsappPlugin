<?php
/**
 * @package  WhatsAppConnectPlugin
 */
namespace Inc\Base;

	class Enqueue extends BaseController{
		function register() {
			add_action('wp_enqueue_scripts', array($this, 'enqueue'));
		}

		// for enqeue the neccessary js and css files
		function enqueue() {
			wp_enqueue_script('jquery');
			wp_register_script( 'style-js-wtasapp', $this->plugin_url.'assets/js/custom.js',array('jquery'), '1.0.1', true );
			wp_enqueue_script( 'style-js-wtasapp');
			wp_enqueue_style( 'style-css-wtasapp12', $this->plugin_url .'assets/css/style.css' );


		}
	}
