<?php
/**
 * @package  WhatsAppConnectPlugin
 */
namespace Inc\Pages;

use Inc\Base\BaseController;

	class User extends BaseController {

		public function register() {
			add_shortcode( 'widget', array($this, 'ShortcodeWidgetOutput' ));
		    add_action( 'wp_footer',array($this, 'WhatsappWidgetPopUp' ));
		}

		// for output the widget using shortcode
		public function ShortcodeWidgetOutput( $atts ) {
			$name= get_the_title( $atts['postid'] );
			$url = wp_get_attachment_url( get_post_thumbnail_id($atts['postid']) );
			if(!empty($url)){
				$image = $url;
			} else {
				$image = $this->plugin_url .'assets/img/whatsapp-default.png';
			}
			$value = get_post_meta($atts['postid'], 'phone_meta_key', true);
			if(!empty($value)){
				include_once('Templates/whatsapp-shortcode-widget.php');
			} else {
				return '';
			}
		}

		public function WhatsappWidgetPopUp ($post_id) {
			include('Templates/whatsapp-window-pop-up.php');
			return $post_id;
		}
	}