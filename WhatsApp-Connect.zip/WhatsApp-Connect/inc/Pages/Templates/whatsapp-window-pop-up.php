<!DOCTYPE html>
<html lang="en-US" class=" ">
    <head>
        <meta charset="UTF-8" />
        <meta name="robots" content="index, follow" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <title>WhatsApp</title>
        <link rel='stylesheet' id='avia-custom-css' href='css/style.css' type='text/css' media='all' />
    </head>
    <body>
        <div class="wa__btn_popup">
            <div class="wa__btn_popup_txt">Need Help?
                <strong>Chat with us</strong>
            </div>
            <div class="wa__btn_popup_icon"></div>
        </div>
        <div class="wa__popup_chat_box">
            <div class="wa__popup_heading">
            <div class="wa__popup_title">Start a Conversation</div>
            <div class="wa__popup_intro">Hi! Click one of our members below to chat on<strong>WhatsApp ;)</strong>
            <div id="\&quot;eJOY__extension_root\&quot;"></div>
        </div>
            <?php $img = $this->plugin_url .'assets/img/cross.png'; ?>
            <span class="cross"><img src='<?php echo $img ?>'></span>
        </div>
        <div class="wa__popup_content wa__popup_content_left">
            <div class="wa__popup_notice">The team typically replies in a few minutes.</div>
            <div class="wa__popup_content_list">
                <?php  $mcpt_query = array();
                $the_query = get_posts('post_type=customposttype');
                foreach ( $the_query as $post) : setup_postdata( $post );  ?>
                <div class="wa__popup_content_item ">
                    <?php  $post_id = $post->ID;
                    $value = get_post_meta($post_id, 'phone_meta_key', true);?>
                    <a target="_blank" href="https://wa.me/<?php echo $value ?>?text=I%20am%20interested%20in%20your%20service" class="wa__stt wa__stt_online">
                        <div class="wa__popup_avatar">
                            <?php $post_id = $post->ID;
                            if ( get_the_post_thumbnail( $post->ID) ) {
                            $featured_img_url = get_the_post_thumbnail_url($post->ID,'full');
                            }  else {
                            $featured_img_url = $this->plugin_url .'assets/img/whatsapp-default.png';  }  ?>
                            <div class="wa__cs_img_wrap" style="background: url(<?php echo $featured_img_url; ?>) center center no-repeat; background-size: cover;"></div>
                        </div>
                        <div class="wa__popup_txt">
                            <div class="wa__member_name"><?php echo   $post->post_title ?></div>
                            <?php   $post_id = $post->ID;
                                $terms = get_the_terms( $post_id, 'Categorys' );
                                if ( $terms && ! is_wp_error( $terms ) ) :  $v_details = array();
                                foreach ( $terms as $term ) {
                                $v_details[] = $term->name;
                                }
                                $v_detail = join( " </li> <li>", $v_details); ?>
                                <div class="wa__member_duty">
                                   <?php echo $v_detail ?>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php  endif; endforeach; wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </body>
</html>

