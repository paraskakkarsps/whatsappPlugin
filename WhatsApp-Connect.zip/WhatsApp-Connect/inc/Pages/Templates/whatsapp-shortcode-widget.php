<?php $name= get_the_title( $atts['postid'] );
   $url = wp_get_attachment_url( get_post_thumbnail_id($atts['postid']) );
   if(!empty($url)){
   $image = $url;
   } else  {
   $image = $this->plugin_url .'assets/img/whatsapp-default.png';
   }
   $value = get_post_meta($atts['postid'], 'phone_meta_key', true);  ?>
<!DOCTYPE html>
<html>
    <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <title>WhatsApp Connect</title>
    </head>
  <body>
    <div class="textwidget">
      <div id="nta-wabutton-9634" style="margin: 30px 0 30px;">
        <a target="_blank" class="wa__button wa__r_button wa__stt_online wa__btn_w_img " href="https://wa.me/<?php echo $value; ?>?text=I%20am%20interested%20in%20your%20service">
          <div class="wa__cs_img">
            <div class="wa__cs_img_wrap" style="background: url(<?php echo $image; ?>) center center no-repeat; background-size: cover;">
            </div>
          </div>
          <div class="wa__btn_txt">
            <div class="wa__cs_info">
              <div class="wa__cs_name"><?php echo $name; ?></div>
            </div>
            <div class="wa__btn_title">Need help? Chat via WhatsApp</div>
          </div>
        </a>
      </div>
    </div>
   </body>
</html>