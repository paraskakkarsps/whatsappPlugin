<?php
/**
* @package  WhatsAppConnectPlugin
*/
namespace Inc\Pages;

use Inc\Base\BaseController;

class Admin extends BaseController {

	public function register() {
		add_action( 'init', array($this, 'CreateCategory' ) , 0 );
		add_action('add_meta_boxes', array ($this,'AddPhoneNumberBox'), 3);
		add_action('save_post', array($this, 'SavePhoneNumberBoxData' ));
		add_action('add_meta_boxes', array($this, 'AddShortCodeBox' ), 3);
		add_action('save_post', array($this, 'SaveShortCodeBoxData' ));
		add_filter('manage_customposttype_posts_columns',array($this, 'ColumnsField' ));
		add_action( 'manage_posts_custom_column',array($this,'ColumnDataShortCodePhone' ), 10, 2);
	}

	// for creating Category
	public function CreateCategory() {
		$args=array(
		    'label' => 'WhatsApp Connect',
		    'public' => true,
		    'show_ui' => true,
		    'capability_type' => 'post',
		    'hierarchical' => false,
		    'rewrite' => array(
			    'slug' => 'mycustomposttype',
			    'with_front' => false,
			),
		    'query_var' => true,
		    'supports' => array(
			    'title',
			    'custom-fields',
			    'thumbnail',
			    'page-attributes',
			    'custom-fields',
	        )
	    );
	    register_post_type( 'customposttype', $args );

		$labels = array(
		    'name' => _x( 'Category', 'taxonomy general name' ),
		    'singular_name' => _x( 'Category', 'taxonomy singular name' ),
		    'all_items' => __( 'All Categories' ),
		    'parent_item' => __( 'Parent Category' ),
		    'parent_item_colon' => __( 'Parent Category:' ),
		    'edit_item' => __( 'Edit Category' ),
		    'update_item' => __( 'Update Category' ),
		    'add_new_item' => __( 'Add New Category' ),
		    'new_item_name' => __( 'New Category Name' ),
	    );

	    register_taxonomy('Categorys',array('customposttype'), array(
		    'hierarchical' => true,
		    'labels' => $labels,
		    'show_ui' => true,
		    'show_admin_column' => true,
		    'query_var' => true,
		    'rewrite' => array( 'slug' => 'Category' ),
	    ));
    }

    // for Adding Phone Number in the Box
    public function AddPhoneNumberBox() {
		$screens = ['post', 'customposttype'];
		foreach ($screens as $screen) {
            add_meta_box('phone_box_id','Add User Phone Number', array($this, 'AddPhoneNumberBoxHtml'),
				$screen
			);
	    }
	}

	// for Save Phone Number Data in the Box
    public function SavePhoneNumberBoxData($post_id) {
		if(array_key_exists('PhoneField', $_POST)) {
			update_post_meta($post_id,'phone_meta_key',$_POST['PhoneField']
     		);
      	}
  	}

  	// for HTML of Phone Number in the Box
 	public function AddPhoneNumberBoxHtml($post_id) {
 		$post_id = get_the_ID();
		$value = get_post_meta($post_id, 'phone_meta_key', true); ?>
    	<label for="PhoneField">Phone Number ( with country code ) <br> + </label>
      	<input type="text" value="<?php  echo $value ?>" name="PhoneField" id="PhoneField"> <?php
    }

    // for Adding Shortcode in the Box
    public function AddShortCodeBox() {
    	$screens = ['post', 'customposttype'];
        foreach ($screens as $screen) {
        	add_meta_box('shortcode_box_id','Add User shortcode', array($this, 'AddShortCodeBoxHtml'),
		        $screen
	        );
        }
    }

    // for Saving Shortcode data in the Box
    public function SaveShortCodeBoxData($post_id) {
		if (array_key_exists('ShortCodeField', $_POST)) {
            update_post_meta($post_id,'short_meta_key',$_POST['ShortCodeField']
	        );
        }
    }

    // for Add Shortcode  Box HTML
    public function AddShortCodeBoxHtml() {
    	$postidb = get_the_ID();
        $value = get_post_meta($newVar, 'phone_meta_key', true);?>
        <label for="ShortCodeField">ShortCode</label>
        <input type="text" value="<?php echo '[widget postid ='.$postidb.']'; ?>" name="ShortCodeField" id="ShortCodeField">
	    <?php return $postidb;
	}

    // For creating Column Field for SHORTCODE and PHONE NUMBER
	public function ColumnsField( $columns ) {
		$columns['shortcode_box_id'] = 'ShortCode';
		$columns['phone_box_id'] = 'Phone Number';
		return $columns;
	}

	// For shortcode and Phone data in column
	public function ColumnDataShortCodePhone ( $column_id, $post_id ) {
		switch( $column_id ) {
		case 'shortcode_box_id':
	    	echo ($value = get_post_meta($post_id, 'short_meta_key', true ) ) ? $value : 'No Shortcode generated';
	    break;
	    case 'phone_box_id':
	    	echo ($value = get_post_meta($post_id, 'phone_meta_key', true ) ) ? $value : 'No Phone Number found';
	    break;

	    }
	}
}
